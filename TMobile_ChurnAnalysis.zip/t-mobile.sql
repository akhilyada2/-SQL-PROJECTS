1.Creating a database in SQL Server.

CREATE DATABASE TelcoChurn;
GO

USE TelcoChurn;
GO
2. Create a table schema for the dataset.
CREATE TABLE Customers (
    CustomerID NVARCHAR(50) PRIMARY KEY,
    Gender NVARCHAR(10),
    SeniorCitizen BIT,
    Partner NVARCHAR(10),
    Dependents NVARCHAR(10),
    Tenure INT,
    PhoneService NVARCHAR(10),
    MultipleLines NVARCHAR(50),
    InternetService NVARCHAR(50),
    OnlineSecurity NVARCHAR(50),
    OnlineBackup NVARCHAR(50),
    DeviceProtection NVARCHAR(50),
    TechSupport NVARCHAR(50),
    StreamingTV NVARCHAR(50),
    StreamingMovies NVARCHAR(50),
    Contract NVARCHAR(50),
    PaperlessBilling NVARCHAR(10),
    PaymentMethod NVARCHAR(50),
    MonthlyCharges DECIMAL(10, 2),
    TotalCharges DECIMAL(10, 2),
    Churn NVARCHAR(10)
);
GO
3. import the data using BULK INSERT

BULK INSERT Customers
FROM 'C:\Temp\TelcoCustomerChurn.csv'
WITH (
    FIRSTROW = 2, -- Skips the header row
    FIELDTERMINATOR = ',', -- Fields separated by commas
    ROWTERMINATOR = '\n', -- Rows separated by new lines
    TEXTQUALIFIER = '"'
);
GO
4. verfing 10 customers 

SELECT TOP 10 * FROM Customers;

5.Exploratory Analysis:
Count of churned and non-churned customers.

SELECT Churn, COUNT(*) AS CustomerCount
FROM Customers
GROUP BY Churn;

6.Average tenure for churned vs. non-churned customers.

SELECT Churn, AVG(Tenure) AS AverageTenure
FROM Customers
GROUP BY Churn;
7.Revenue loss due to churn.
SELECT 
    SUM(MonthlyCharges * Tenure) AS RevenueLost
FROM Customers
WHERE Churn = 'Yes';

8.Cohort Analysis
Analyze retention rates based on customer tenure cohorts.

8.a Create cohorts by grouping customers based on their tenure.
SELECT 
    CASE 
        WHEN Tenure <= 12 THEN '0-12 months'
        WHEN Tenure <= 24 THEN '13-24 months'
        WHEN Tenure <= 36 THEN '25-36 months'
        WHEN Tenure <= 48 THEN '37-48 months'
        WHEN Tenure <= 60 THEN '49-60 months'
        ELSE '61+ months'
    END AS TenureGroup,
    COUNT(*) AS CustomerCount,
    SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS ChurnedCount
FROM Customers
GROUP BY 
    CASE 
        WHEN Tenure <= 12 THEN '0-12 months'
        WHEN Tenure <= 24 THEN '13-24 months'
        WHEN Tenure <= 36 THEN '25-36 months'
        WHEN Tenure <= 48 THEN '37-48 months'
        WHEN Tenure <= 60 THEN '49-60 months'
        ELSE '61+ months'
    END;
8.b Calculate retention percentage.
SELECT 
    TenureGroup,
    (CustomerCount - ChurnedCount) * 100.0 / CustomerCount AS RetentionPercentage
FROM (
    SELECT 
        CASE 
            WHEN Tenure <= 12 THEN '0-12 months'
            WHEN Tenure <= 24 THEN '13-24 months'
            WHEN Tenure <= 36 THEN '25-36 months'
            WHEN Tenure <= 48 THEN '37-48 months'
            WHEN Tenure <= 60 THEN '49-60 months'
            ELSE '61+ months'
        END AS TenureGroup,
        COUNT(*) AS CustomerCount,
        SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS ChurnedCount
    FROM Customers
    GROUP BY 
        CASE 
            WHEN Tenure <= 12 THEN '0-12 months'
            WHEN Tenure <= 24 THEN '13-24 months'
            WHEN Tenure <= 36 THEN '25-36 months'
            WHEN Tenure <= 48 THEN '37-48 months'
            WHEN Tenure <= 60 THEN '49-60 months'
            ELSE '61+ months'
        END
) AS CohortData;

9.Time-Series Analysis
Use MONTHLY CHARGES and CHURN to analyze patterns over time.

Group churned customers by their tenure (time-based analysis).
SELECT 
    Tenure,
    COUNT(*) AS ChurnedCustomers
FROM Customers
WHERE Churn = 'Yes'
GROUP BY Tenure
ORDER BY Tenure;

10.Common Table Expressions (CTEs)
Organize complex queries, such as churn rate by tenure and contract type.

Calculate churn rate by contract type using a CTE.
WITH ContractChurn AS (
    SELECT 
        Contract,
        COUNT(*) AS TotalCustomers,
        SUM(CASE WHEN Churn = 'Yes' THEN 1 ELSE 0 END) AS ChurnedCustomers
    FROM Customers
    GROUP BY Contract
)
SELECT 
    Contract,
    ChurnedCustomers * 100.0 / TotalCustomers AS ChurnRate
FROM ContractChurn;

11.Final Report
Combine insights into a summary report.

SELECT 
    (SELECT COUNT(*) FROM Customers) AS TotalCustomers,
    (SELECT COUNT(*) FROM Customers WHERE Churn = 'Yes') AS ChurnedCustomers,
    (SELECT AVG(Tenure) FROM Customers WHERE Churn = 'Yes') AS AvgChurnedTenure,
    (SELECT SUM(MonthlyCharges * Tenure) FROM Customers WHERE Churn = 'Yes') AS RevenueLost
